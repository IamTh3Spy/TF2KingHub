// Contenido simulado para server.js
