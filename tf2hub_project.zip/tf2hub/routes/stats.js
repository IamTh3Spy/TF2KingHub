// Contenido simulado para stats.js
