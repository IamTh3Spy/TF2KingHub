// Contenido simulado para inventory.js
