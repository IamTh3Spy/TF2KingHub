// Contenido simulado para loadouts.js
