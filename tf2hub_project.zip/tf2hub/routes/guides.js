// Contenido simulado para guides.js
